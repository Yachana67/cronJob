package com.category.ExcelData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
